<?php if (isset($component)) { $__componentOriginal10ee9096696ab4b6c09fba1b4a1a2089 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal10ee9096696ab4b6c09fba1b4a1a2089 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.shop-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('shop-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                Expenses
            </h2>
            <a href="<?php echo e(route('expenses.create')); ?>" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md text-sm font-medium transition-colors duration-200">
                Record New Expense
            </a>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="space-y-6">
        <!-- Filters -->
        <div class="bg-white overflow-hidden shadow-sm rounded-lg">
            <div class="p-6">
                <form method="GET" class="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div>
                        <label for="start_date" class="block text-sm font-medium text-gray-700">Start Date</label>
                        <input type="date" name="start_date" id="start_date" value="<?php echo e(request('start_date')); ?>"
                               class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 shadow-sm focus:ring focus:ring-blue-500">
                    </div>

                    <div>
                        <label for="end_date" class="block text-sm font-medium text-gray-700">End Date</label>
                        <input type="date" name="end_date" id="end_date" value="<?php echo e(request('end_date')); ?>"
                               class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 shadow-sm focus:ring focus:ring-blue-500">
                    </div>

                    <div>
                        <label for="supplier" class="block text-sm font-medium text-gray-700">Expenses Title</label>
                        <input type="text" name="supplier" id="supplier" value="<?php echo e(request('supplier')); ?>" placeholder="Supplier name"
                               class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 shadow-sm focus:ring focus:ring-blue-500">
                    </div>

                    <div class="flex items-end">
                        <button type="submit" class="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-md text-sm font-medium mr-2">
                            Filter
                        </button>
                        <a href="<?php echo e(route('expenses.index')); ?>" class="bg-gray-300 hover:bg-gray-400 text-gray-800 px-4 py-2 rounded-md text-sm font-medium">
                            Clear
                        </a>
                    </div>
                </form>
            </div>
        </div>

        <!-- Summary Cards -->
        <?php if($expenses->count() > 0): ?>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div class="bg-white shadow-sm rounded-lg p-6 text-center">
                    <p class="text-sm text-gray-500">Total Expenses Amount</p>
                    <p class="text-2xl font-bold text-blue-600">₦<?php echo e(number_format($expenses->sum('amount'), 2)); ?></p>
                </div>
                <div class="bg-white shadow-sm rounded-lg p-6 text-center">
                    <p class="text-sm text-gray-500">Total Expenses</p>
                    <p class="text-2xl font-bold text-green-600"><?php echo e(number_format($expenses->count(), 1)); ?></p>
                </div>
                <div class="bg-white shadow-sm rounded-lg p-6 text-center">
                    <p class="text-sm text-gray-500">Total Transactions</p>
                    <p class="text-2xl font-bold text-gray-800"><?php echo e($expenses->count()); ?></p>
                </div>
            </div>
        <?php endif; ?>

        <!-- Expenses Table -->
        <div class="bg-white shadow-sm rounded-lg overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Supplier	</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Expense Title</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Today's Profit</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Expense Amount</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Today's Net Profit</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Notes</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Recorded By</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                    </tr>                    
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php $__empty_1 = true; $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-gray-50">
                            <td class="px-6 py-4 text-sm text-gray-900 whitespace-nowrap">
                                <?php echo e($expense->created_at->format('M d, Y')); ?>

                            </td>
                            <td class="px-6 py-4 text-sm text-gray-900 whitespace-nowrap">
                                <?php echo e($expense->user->name); ?>

                            </td>
                            	
                            <td class="px-6 py-4 text-sm text-gray-900 whitespace-nowrap">
                                <?php echo e($expense->name); ?>

                            </td>
                           
                            <td class="px-6 py-4 text-sm text-blue-600 font-medium whitespace-nowrap">
                                ₦<?php echo e(number_format($expense->today_profit, 2)); ?>

                            </td>
                            <td class="px-6 py-4 text-sm text-blue-600 font-medium whitespace-nowrap">
                                ₦<?php echo e(number_format($expense->amount, 2)); ?>

                            </td>
                            <td class="px-6 py-4 text-sm text-blue-600 font-medium whitespace-nowrap">
                                ₦<?php echo e(number_format($expense->today_net_profit, 2)); ?>

                            </td>
                            <td class="px-6 py-4 text-sm text-gray-900 whitespace-nowrap">
                                <?php echo e($expense->notes); ?>

                            </td>
                            <td class="px-6 py-4 text-sm text-gray-900 whitespace-nowrap">
                                <?php echo e(optional($expense->user)->name ?? '-'); ?>

                            </td>
                            <td class="px-6 py-4 text-sm text-gray-500 whitespace-nowrap">
                                
                                <a href="">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="px-6 py-4 text-center text-sm text-gray-500">
                                No expenses found.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <?php if($expenses->hasPages()): ?>
                <div class="px-6 py-4 border-t border-gray-200">
                    <?php echo e($expenses->appends(request()->query())->links()); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal10ee9096696ab4b6c09fba1b4a1a2089)): ?>
<?php $attributes = $__attributesOriginal10ee9096696ab4b6c09fba1b4a1a2089; ?>
<?php unset($__attributesOriginal10ee9096696ab4b6c09fba1b4a1a2089); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal10ee9096696ab4b6c09fba1b4a1a2089)): ?>
<?php $component = $__componentOriginal10ee9096696ab4b6c09fba1b4a1a2089; ?>
<?php unset($__componentOriginal10ee9096696ab4b6c09fba1b4a1a2089); ?>
<?php endif; ?>
<?php /**PATH /home/mrcode/Videos/palm-oil-shop-fixed/resources/views/expenses/index.blade.php ENDPATH**/ ?>