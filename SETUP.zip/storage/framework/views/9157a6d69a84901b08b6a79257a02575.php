<?php if (isset($component)) { $__componentOriginal10ee9096696ab4b6c09fba1b4a1a2089 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal10ee9096696ab4b6c09fba1b4a1a2089 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.shop-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('shop-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                Profit Analysis Report
            </h2>
            <a href="<?php echo e(route('reports.index')); ?>" class="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-md text-sm font-medium transition-colors duration-200">
                Back to Reports
            </a>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="space-y-6">
        <!-- Filters -->
        <div class="bg-white overflow-hidden shadow-sm rounded-lg">
            <div class="p-6">
                <form method="GET" class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                        <label for="period" class="block text-sm font-medium text-gray-700">Period</label>
                        <select id="period" 
                                name="period" 
                                class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                            <option value="monthly" <?php echo e($period == 'monthly' ? 'selected' : ''); ?>>Monthly</option>
                            <option value="daily" <?php echo e($period == 'daily' ? 'selected' : ''); ?>>Daily (Current Month)</option>
                        </select>
                    </div>

                    <?php if($period == 'monthly'): ?>
                        <div>
                            <label for="year" class="block text-sm font-medium text-gray-700">Year</label>
                            <select id="year" 
                                    name="year" 
                                    class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                                <?php for($i = date('Y'); $i >= date('Y') - 5; $i--): ?>
                                    <option value="<?php echo e($i); ?>" <?php echo e($year == $i ? 'selected' : ''); ?>><?php echo e($i); ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                    <?php endif; ?>

                    <div class="flex items-end">
                        <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md text-sm font-medium transition-colors duration-200">
                            Generate Report
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Summary Cards -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div class="bg-white overflow-hidden shadow-sm rounded-lg">
                <div class="p-6 text-center">
                    <p class="text-sm text-gray-500">Total Sales</p>
                    <p class="text-2xl font-bold text-green-600">₦<?php echo e(number_format($profits->sum('sales'), 2)); ?></p>
                </div>
            </div>
            <div class="bg-white overflow-hidden shadow-sm rounded-lg">
                <div class="p-6 text-center">
                    <p class="text-sm text-gray-500">Total Profit</p>
                    <p class="text-2xl font-bold text-blue-600">₦<?php echo e(number_format($profits->sum('profit'), 2)); ?></p>
                </div>
            </div>
            <div class="bg-white overflow-hidden shadow-sm rounded-lg">
                <div class="p-6 text-center">
                    <p class="text-sm text-gray-500">Average Margin</p>
                    <p class="text-2xl font-bold text-purple-600">
                        <?php echo e($profits->sum('sales') > 0 ? number_format(($profits->sum('profit') / $profits->sum('sales')) * 100, 1) : 0); ?>%
                    </p>
                </div>
            </div>
        </div>

        <!-- Profit Chart Visualization -->
        <div class="bg-white overflow-hidden shadow-sm rounded-lg">
            <div class="p-6">
                <h3 class="text-lg font-medium text-gray-900 mb-4">
                    <?php echo e($period == 'monthly' ? 'Monthly' : 'Daily'); ?> Profit Trend
                </h3>
                <div class="h-64 flex items-end justify-between space-x-2">
                    <?php $__currentLoopData = $profits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $profit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $maxProfit = $profits->max('profit');
                            $height = $maxProfit > 0 ? ($profit['profit'] / $maxProfit) * 100 : 0;
                        ?>
                        <div class="flex-1 flex flex-col items-center">
                            <div class="w-full bg-blue-500 rounded-t" style="height: <?php echo e($height); ?>%"></div>
                            <div class="text-xs text-gray-600 mt-2 text-center">
                                <?php echo e($period == 'monthly' ? substr($profit['period'], 0, 3) : substr($profit['period'], -2)); ?>

                            </div>
                            <div class="text-xs text-blue-600 font-medium">
                                ₦<?php echo e(number_format($profit['profit'], 0)); ?>

                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>

        <!-- Detailed Profit Data -->
        <div class="bg-white overflow-hidden shadow-sm rounded-lg">
            <div class="p-6">
                <h3 class="text-lg font-medium text-gray-900 mb-4">Detailed Profit Analysis</h3>
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Period</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Sales</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Profit</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Margin</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Performance</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php $__currentLoopData = $profits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="hover:bg-gray-50">
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                        <?php echo e($profit['period']); ?>

                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-green-600">
                                        ₦<?php echo e(number_format($profit['sales'], 2)); ?>

                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-blue-600">
                                        ₦<?php echo e(number_format($profit['profit'], 2)); ?>

                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                        <?php echo e(number_format($profit['margin'], 1)); ?>%
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <?php if($profit['margin'] >= 30): ?>
                                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                                Excellent
                                            </span>
                                        <?php elseif($profit['margin'] >= 20): ?>
                                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                                Good
                                            </span>
                                        <?php elseif($profit['margin'] >= 10): ?>
                                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                                                Average
                                            </span>
                                        <?php else: ?>
                                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                                                Poor
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Insights -->
        <div class="bg-white overflow-hidden shadow-sm rounded-lg">
            <div class="p-6">
                <h3 class="text-lg font-medium text-gray-900 mb-4">Key Insights</h3>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <h4 class="text-sm font-medium text-gray-700 mb-2">Best Performing Period</h4>
                        <?php
                            $bestPeriod = $profits->sortByDesc('profit')->first();
                        ?>
                        <?php if($bestPeriod): ?>
                            <div class="bg-green-50 p-3 rounded-md">
                                <p class="text-sm font-medium text-green-800"><?php echo e($bestPeriod['period']); ?></p>
                                <p class="text-xs text-green-600">₦<?php echo e(number_format($bestPeriod['profit'], 2)); ?> profit (<?php echo e(number_format($bestPeriod['margin'], 1)); ?>% margin)</p>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div>
                        <h4 class="text-sm font-medium text-gray-700 mb-2">Lowest Performing Period</h4>
                        <?php
                            $worstPeriod = $profits->sortBy('profit')->first();
                        ?>
                        <?php if($worstPeriod): ?>
                            <div class="bg-red-50 p-3 rounded-md">
                                <p class="text-sm font-medium text-red-800"><?php echo e($worstPeriod['period']); ?></p>
                                <p class="text-xs text-red-600">₦<?php echo e(number_format($worstPeriod['profit'], 2)); ?> profit (<?php echo e(number_format($worstPeriod['margin'], 1)); ?>% margin)</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="mt-4">
                    <h4 class="text-sm font-medium text-gray-700 mb-2">Recommendations</h4>
                    <ul class="text-sm text-gray-600 space-y-1">
                        <?php if($profits->avg('margin') < 20): ?>
                            <li>• Consider reviewing pricing strategy to improve profit margins</li>
                        <?php endif; ?>
                        <?php if($profits->where('profit', 0)->count() > 0): ?>
                            <li>• Focus on periods with zero profit to identify improvement opportunities</li>
                        <?php endif; ?>
                        <li>• Analyze best performing periods to replicate success strategies</li>
                        <li>• Monitor inventory turnover to optimize stock levels</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal10ee9096696ab4b6c09fba1b4a1a2089)): ?>
<?php $attributes = $__attributesOriginal10ee9096696ab4b6c09fba1b4a1a2089; ?>
<?php unset($__attributesOriginal10ee9096696ab4b6c09fba1b4a1a2089); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal10ee9096696ab4b6c09fba1b4a1a2089)): ?>
<?php $component = $__componentOriginal10ee9096696ab4b6c09fba1b4a1a2089; ?>
<?php unset($__componentOriginal10ee9096696ab4b6c09fba1b4a1a2089); ?>
<?php endif; ?>

<?php /**PATH /home/mrcode/Videos/palm-oil-shop-fixed/resources/views/reports/profit.blade.php ENDPATH**/ ?>