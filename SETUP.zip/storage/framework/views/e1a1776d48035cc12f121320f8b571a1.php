<?php if (isset($component)) { $__componentOriginal10ee9096696ab4b6c09fba1b4a1a2089 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal10ee9096696ab4b6c09fba1b4a1a2089 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.shop-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('shop-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Record New Expense
        </h2>
     <?php $__env->endSlot(); ?>

    <?php
        // Get current time in 24-hour format
        $currentHour = now()->format('H');
    ?>

    <div class="max-w-3xl">
        <div class="bg-white overflow-hidden shadow-sm rounded-lg">
            <div class="p-6">
                <?php if($currentHour < 7): ?>
                    <!-- Locked Message -->
                    <div class="bg-yellow-100 border border-yellow-400 text-yellow-700 px-4 py-3 rounded relative" role="alert">
                        <strong class="font-bold">Access Locked!</strong>
                        <span class="block sm:inline">You can only record expenses after <strong>5:00 PM</strong>. Please try again later.</span>
                    </div>
                    <?php else: ?>
                    <!-- Expense Form -->
                    <form method="POST" action="<?php echo e(route('expenses.store')); ?>" class="space-y-6">
                        <?php echo csrf_field(); ?>

                       
                        <!-- Expense Name -->
                        <div>
                            <label for="name" class="block text-sm font-medium text-gray-700">Expense Title</label>
                            <input type="text" id="name" name="name" value="<?php echo e(old('name')); ?>" required
                                class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm px-3 py-2 focus:ring-blue-500 focus:border-blue-500">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-sm text-red-600"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Amount -->
                        <div>
                            <label for="amount" class="block text-sm font-medium text-gray-700">Amount (₦)</label>
                            <input type="number" id="amount" name="amount" step="0.01" min="0"
                                value="<?php echo e(old('amount')); ?>" required
                                class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm px-3 py-2 focus:ring-blue-500 focus:border-blue-500">
                            <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-sm text-red-600"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Date -->
                        <div>
                            <label for="date" class="block text-sm font-medium text-gray-700">Date</label>
                            <input type="date" id="date" name="date" value="<?php echo e(old('date', date('Y-m-d'))); ?>"
                                required
                                class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm px-3 py-2 focus:ring-blue-500 focus:border-blue-500">
                            <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-sm text-red-600"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Notes -->
                        <div>
                            <label for="notes" class="block text-sm font-medium text-gray-700">Notes (Optional)</label>
                            <textarea id="notes" name="notes" rows="3"
                                class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm px-3 py-2 focus:ring-blue-500 focus:border-blue-500"><?php echo e(old('notes')); ?></textarea>
                            <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-sm text-red-600"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Submit -->
                        <div class="flex justify-between items-center pt-4">
                            <a href="<?php echo e(route('expenses.index')); ?>"
                                class="bg-gray-300 hover:bg-gray-400 text-gray-800 font-medium py-2 px-4 rounded-md transition">
                                Cancel
                            </a>
                            <button type="submit"
                                class="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-6 rounded-md transition">
                                Save Expense
                            </button>
                        </div>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal10ee9096696ab4b6c09fba1b4a1a2089)): ?>
<?php $attributes = $__attributesOriginal10ee9096696ab4b6c09fba1b4a1a2089; ?>
<?php unset($__attributesOriginal10ee9096696ab4b6c09fba1b4a1a2089); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal10ee9096696ab4b6c09fba1b4a1a2089)): ?>
<?php $component = $__componentOriginal10ee9096696ab4b6c09fba1b4a1a2089; ?>
<?php unset($__componentOriginal10ee9096696ab4b6c09fba1b4a1a2089); ?>
<?php endif; ?>
<?php /**PATH /home/mrcode/Videos/palm-oil-shop-fixed/resources/views/expenses/create.blade.php ENDPATH**/ ?>